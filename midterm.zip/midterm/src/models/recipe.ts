export class Recipe {
    idMeal: string;
    strMeal: string;
    strDrinkAlternate: null;
    strCategory: string;
    strArea: string;
    strInstructions: string;
}