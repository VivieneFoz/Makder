<?php
	
	include('dbconfig/config.php');
    session_start();
	//phpinfo();
?>

<!DOCTYPE html>
<html>
<head>
<title>iBorrow</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
  <a class="navbar-brand" href="#">iBorrow</a>
</nav>
<div id="main-wrapper">
  <div id="formContent">
 <div class="fadeIn first">
      <center><h1>Student</h1></center>
    </div>
			<div class="imgcontainer">
				<img src="imgs/avatar.png" alt="Avatar" class="avatar">
			</div>
		<form action="mema.php" method="post">
		
			<div class="inner_container">
				<label><b>ID Number</b></label>
                <input type="text" id="id number" class="fadeIn second" name="id number" placeholder="ID Number" required>
				<button class="login_button" name="login" type="submit">Login</button>
			</div>
		</form>
		</div>
    
    		<?php
			if(isset($_POST['login']))
			{
				@$idnum=$_POST['idnum'];
				$query = "select * from login where idnum='$idnum' ";
				//echo $query;
				$query_run = mysqli_query($con,$query);
				//echo mysql_num_rows($query_run);
				if($query_run)
				{
					if(mysqli_num_rows($query_run)>0)
					{
                    echo '<script type="text/javascript">alert("This Username Already exists.. Please try another username!")</script>';
					$row = mysqli_fetch_array($query_run,MYSQLI_ASSOC);
					
					$_SESSION['idnum'] = $idnum;
					
					header( "Location: mema.php");
					}
					else
					{
						echo '<script type="text/javascript">alert("No such User exists. Invalid Credentials")</script>';
					}
				}
				else
				{
					echo '<script type="text/javascript">alert("Database Error")</script>';
				}
			}
			else
			{
			}
		?>
		
	</div>
</body>
</html>