import { Recipe } from '../models/recipe';
export var recipesList: Recipe[] = [
    {
        idMeal:"52804",
        strMeal:"Poutine",
        strDrinkAlternate:null,
        strCategory:"Miscellaneous",
        strArea:"Canadian",
        strInstructions:"Heat oil in a deep fryer or deep heavy skillet to 365°F (185°C). Warm gravy in saucepan or microwave. Place the fries into the hot oil, and cook until light brown, about 5 minutes. Remove to a paper towel lined plate to drain. Place the fries on a serving platter, and sprinkle the cheese over them. Ladle gravy over the fries and cheese, and serve immediately."
    },
    {
        idMeal:"52804",
        strMeal:"Poutine",
        strDrinkAlternate:null,
        strCategory:"Miscellaneous",
        strArea:"Canadian",
        strInstructions:"Heat oil in a deep fryer or deep heavy skillet to 365°F (185°C). Warm gravy in saucepan or microwave. Place the fries into the hot oil, and cook until light brown, about 5 minutes. Remove to a paper towel lined plate to drain. Place the fries on a serving platter, and sprinkle the cheese over them. Ladle gravy over the fries and cheese, and serve immediately."
    },
    {
        idMeal:"52804",
        strMeal:"Poutine",
        strDrinkAlternate:null,
        strCategory:"Miscellaneous",
        strArea:"Canadian",
        strInstructions:"Heat oil in a deep fryer or deep heavy skillet to 365°F (185°C). Warm gravy in saucepan or microwave. Place the fries into the hot oil, and cook until light brown, about 5 minutes. Remove to a paper towel lined plate to drain. Place the fries on a serving platter, and sprinkle the cheese over them. Ladle gravy over the fries and cheese, and serve immediately."
    },
    {
        idMeal:"52804",
        strMeal:"Poutine",
        strDrinkAlternate:null,
        strCategory:"Miscellaneous",
        strArea:"Canadian",
        strInstructions:"Heat oil in a deep fryer or deep heavy skillet to 365°F (185°C). Warm gravy in saucepan or microwave. Place the fries into the hot oil, and cook until light brown, about 5 minutes. Remove to a paper towel lined plate to drain. Place the fries on a serving platter, and sprinkle the cheese over them. Ladle gravy over the fries and cheese, and serve immediately."
    },
    {
        idMeal:"52804",
        strMeal:"Poutine",
        strDrinkAlternate:null,
        strCategory:"Miscellaneous",
        strArea:"Canadian",
        strInstructions:"Heat oil in a deep fryer or deep heavy skillet to 365°F (185°C). Warm gravy in saucepan or microwave. Place the fries into the hot oil, and cook until light brown, about 5 minutes. Remove to a paper towel lined plate to drain. Place the fries on a serving platter, and sprinkle the cheese over them. Ladle gravy over the fries and cheese, and serve immediately."
    },
    {
        idMeal:"52804",
        strMeal:"Poutine",
        strDrinkAlternate:null,
        strCategory:"Miscellaneous",
        strArea:"Canadian",
        strInstructions:"Heat oil in a deep fryer or deep heavy skillet to 365°F (185°C). Warm gravy in saucepan or microwave. Place the fries into the hot oil, and cook until light brown, about 5 minutes. Remove to a paper towel lined plate to drain. Place the fries on a serving platter, and sprinkle the cheese over them. Ladle gravy over the fries and cheese, and serve immediately."
    },

];