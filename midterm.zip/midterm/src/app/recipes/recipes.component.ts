import { Component, OnInit } from '@angular/core';
import { Recipe } from '../../models/recipe';
import { recipesList } from '../recipes-list';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrls: ['./recipes.component.css']
})
export class RecipesComponent implements OnInit {
  recipe: Recipe = {
    idMeal: "52804",
    strMeal: "Poutine",
    strDrinkAlternate: null,
    strCategory: "Miscellaneous",
    strArea: "Canadian",
    strInstructions: "Heat oil in a deep fryer or deep heavy skillet to 365\u00b0F (185\u00b0C).\r\nWarm gravy in saucepan or microwave.\r\nPlace the fries into the hot oil, and cook until light brown, about 5 minutes.\r\nRemove to a paper towel lined plate to drain.\r\nPlace the fries on a serving platter, and sprinkle the cheese over them.\r\nLadle gravy over the fries and cheese, and serve immediately."


  }
  recipes = recipesList;
  constructor() { }

  ngOnInit() {
  }
  //Action when selecting a Recipe in List item
  selectRecipe: Recipe;
  onSelect(recipe: Recipe): void {
    this.selectRecipe = recipe;
  }

}
